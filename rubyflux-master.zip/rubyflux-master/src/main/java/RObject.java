
public class RObject extends RKernel {
    /* This class is just provided as a stub to allow subclasses to compile.
       In a real run, it is generated anew based on input scripts. */
}
