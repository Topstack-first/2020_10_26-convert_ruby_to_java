module Nodes
  class Block < Node
  end
end
