module Nodes
  class Operation < Expression
  end
end
